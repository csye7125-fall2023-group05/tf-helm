# [1.1.0](https://github.com/csye7125-fall2023-group05/infra-helm-chart/compare/v1.0.0...v1.1.0) (2023-11-10)


### Features

* add provisioner logic to kafka dependency chart ([9bf1622](https://github.com/csye7125-fall2023-group05/infra-helm-chart/commit/9bf1622907d6806b1fb082096dbb15a9568c64d0))

# 1.0.0 (2023-11-10)


### Bug Fixes

* ci lint test ([bd48ce1](https://github.com/csye7125-fall2023-group05/infra-helm-chart/commit/bd48ce1974488f1983e54dafb66701750da04130))


### Features

* install bitnami/kafka dependency helm chart ([b5c54f3](https://github.com/csye7125-fall2023-group05/infra-helm-chart/commit/b5c54f3423fec72f077a3e2bb284b12d633f688d)), closes [#1](https://github.com/csye7125-fall2023-group05/infra-helm-chart/issues/1)
